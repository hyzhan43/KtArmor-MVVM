package com.zhan.mvvm.common

/**
 * @author  hyzhan
 * @date    2019/5/23
 * @desc    TODO
 */
enum class SharedType{
    SUCCESS,
    ERROR,
    LOADING,
    TIPS,
    EMPTY,
}