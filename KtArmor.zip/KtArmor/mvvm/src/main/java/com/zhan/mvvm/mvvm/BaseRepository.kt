package com.zhan.mvvm.mvvm


/**
 * @author  hyzhan
 * @date    2019/5/22
 * @desc    TODO
 */
abstract class BaseRepository {


}