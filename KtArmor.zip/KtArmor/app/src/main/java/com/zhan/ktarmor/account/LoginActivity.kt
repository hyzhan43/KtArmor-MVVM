package com.zhan.ktarmor.account

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import com.zhan.ktarmor.R
import com.zhan.mvvm.ext.Toasts.toast
import com.zhan.mvvm.ext.log
import com.zhan.mvvm.ext.showLog
import com.zhan.mvvm.ext.str
import com.zhan.mvvm.mvvm.LifecycleActivity
import kotlinx.android.synthetic.main.activity_login.*
import kotlin.math.log

/**
 * @author  hyzhan
 * @date    2019/5/22
 * @desc    TODO
 */
class LoginActivity : LifecycleActivity<AccountViewModel>() {


    override fun getLayoutId(): Int = R.layout.activity_login

    override fun getViewModel(): Class<AccountViewModel> = AccountViewModel::class.java

    override fun initView() {

        mBtnLogin.setOnClickListener {
            viewModel.login(mEtAccount.str(), mEtPassword.str())
        }
    }

    override fun dataObserver() {
        viewModel.loginData.observe(this, Observer {
            toast(it?.errorMsg ?: "错误")
        })
    }
}