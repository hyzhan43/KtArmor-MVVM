package com.zhan.ktarmor.account

import android.app.Application
import android.arch.lifecycle.MutableLiveData
import android.text.TextUtils
import android.util.Log
import com.zhan.ktarmor.R
import com.zhan.ktarmor.account.data.AccountRepository
import com.zhan.ktarmor.account.data.response.LoginRsp
import com.zhan.ktarmor.common.data.BaseResponse
import com.zhan.mvvm.common.SharedData
import com.zhan.mvvm.mvvm.BaseViewModel
import kotlinx.coroutines.*

/**
 * @author  hyzhan
 * @date    2019/5/23
 * @desc    TODO
 */
class AccountViewModel(application: Application) : BaseViewModel<AccountRepository>(application) {

    var loginData: MutableLiveData<BaseResponse<LoginRsp>> = MutableLiveData()

    override fun bindRepository(): AccountRepository = AccountRepository()

    fun login(account: String, password: String) {

        if (TextUtils.isEmpty(account) || TextUtils.isEmpty(password)) {
            sharedData.value = SharedData(strRes = R.string.account_or_password_empty)
        } else {
            launch {
                loginData.value = repository.login(account, password)
            }
        }
    }
}