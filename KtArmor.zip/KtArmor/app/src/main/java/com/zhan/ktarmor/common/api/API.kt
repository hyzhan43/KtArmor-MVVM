package com.zhan.ktarmor.common.api

/**
 * @author  hyzhan
 * @date    2019/5/28
 * @desc    TODO
 */
object API{

    const val BASE_URL = "https://www.wanandroid.com"

    const val LOGIN = "/user/login"
}